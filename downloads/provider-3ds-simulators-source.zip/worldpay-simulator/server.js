#!/usr/bin/env node
/**
 * Worldpay Own (native) 3DS — "3DS Flex" / Cardinal — Simulator.
 * . Zero-dependency Node server + web UI.
 *
 * Models the WPG / XML Direct own-3DS flow that the `internal-service` adapter builds:
 *   1. Mint the DDC JWT server-side (HS256, MAC key)  ............ 
 *   2. (simulated) DDC device fingerprint -> dfReferenceId ....... 
 *   3. First authorise (additional3DSData + session id) .......... 
 *   4a. Frictionless  -> AUTHORISED
 *   4b. <challengeRequired> -> ACS iframe -> second authorise
 *       with <info3DSecure><completedAuthentication/></info3DSecure> . 
 *   5. Map result to Acme Pay status / three_d_secure ................ 
 * Plus the EXTERNAL-MPI ("today") XML for the golden-baseline diff . 
 *
 * MODE:
 *   mock (default) — a built-in fake Worldpay WPG + fake bank ACS. Runs offline.
 *   live           — POSTs real WPG XML to WORLDPAY_URL with Basic auth.
 *                    Needs the B-1 credentials; this is what clears B-1/B-3.
 *
 *   node worldpay-simulator/server.js
 *   open http://localhost:4100
 */
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const CFG = {
  mode:      process.env.WORLDPAY_MODE || 'mock',            // 'mock' | 'live'
  port:      process.env.PORT || 4100,
  url:       process.env.WORLDPAY_URL || '',                 // live WPG XML endpoint
  merchant:  process.env.WORLDPAY_MERCHANT || 'DEMOMERCHANT3D',
  user:      process.env.WORLDPAY_USER || '',
  password:  process.env.WORLDPAY_PASSWORD || '',
  // 3DS-Flex creds . Blank until Worldpay provides them (B-1).
  issuer:    process.env.THREEDS_FLEX_ISSUER || '5f5e1c...ISSUER',
  orgUnitId: process.env.THREEDS_FLEX_ORG_UNIT_ID || '5bd9e0...ORGUNIT',
  macKey:    process.env.THREEDS_FLEX_JWT_MAC_KEY || 'sandbox-placeholder-mac-key-not-real',
  ddcUrl:    process.env.DDC_URL || 'https://centinelapistag.cardinalcommerce.com/V1/Cruise/Collect', // CONFIRMED (live + Worldpay/Cardinal docs)
  stepUpUrl: process.env.STEPUP_URL || 'https://centinelapistag.cardinalcommerce.com/V2/Cruise/StepUp', // CONFIRMED
  jwtAlg:    'HS256',                                          // CONFIRMED (doc example + GOV.UK pay-connector + live JWT decode)
};

// Cardinal 3DS-Flex URLs — only the hostname differs test vs prod (CONFIRMED 2026-07-14)
const CARDINAL = {
  test: { ddc: 'https://centinelapistag.cardinalcommerce.com/V1/Cruise/Collect', stepUp: 'https://centinelapistag.cardinalcommerce.com/V2/Cruise/StepUp' },
  prod: { ddc: 'https://centinelapi.cardinalcommerce.com/V1/Cruise/Collect',     stepUp: 'https://centinelapi.cardinalcommerce.com/V2/Cruise/StepUp' },
};
// WPG XML Direct endpoint (Merchant C DEMOMERCHANT3D creds authenticate here — live-verified)
const WPG = { sandbox: process.env.WPG_URL || 'https://secure-test.worldpay.com/jsp/merchant/xml/paymentService.jsp' };

// JSON / Access Worldpay v7 config . Sandbox is READY — this side can run LIVE.
const ACCESS = {
  sandbox:  'https://try.access.worldpay.com',
  prod:     'https://access.worldpay.com',
  entity:   process.env.WP_ENTITY || 'DEMOENTITY',
  username: process.env.WP_USERNAME || '',        // e.g. demo-user — supply to go live
  password: process.env.WP_PASSWORD || '',
  ctype:    'application/vnd.worldpay.payments-v7+json',
};

// ---------- helpers ----------
const b64url = (buf) =>
  Buffer.from(buf).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');

// DDC JWT — server-minted, HS256/HS512. Claims per : iss, OrgUnitId, jti, iat, exp.
function mintJwt({ issuer, orgUnitId, macKey, alg = 'HS256', ttl = 3600, returnUrl }) {
  const now = Math.floor(Date.now() / 1000);
  const header = { alg, typ: 'JWT' };
  const payload = { jti: crypto.randomUUID(), iat: now, exp: now + ttl, iss: issuer, OrgUnitId: orgUnitId };
  if (returnUrl) payload.ReturnUrl = returnUrl;            // challenge JWT adds ReturnUrl (same MAC key)
  const signingInput = b64url(JSON.stringify(header)) + '.' + b64url(JSON.stringify(payload));
  const hmacAlg = alg === 'HS512' ? 'sha512' : 'sha256';
  const sig = b64url(crypto.createHmac(hmacAlg, macKey).update(signingInput).digest());
  return { jwt: signingInput + '.' + sig, header, payload };
}

const deriveBin = (pan) => String(pan || '').replace(/\D/g, '').slice(0, 8); // Cardinal wants BIN (6-8)
const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
const unesc = (s) => (s == null ? s : String(s).replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>'));
const rx = (xml, tag) => { const m = xml.match(new RegExp('<' + tag + '[^>]*>([\\s\\S]*?)</' + tag + '>')); return m ? unesc(m[1].trim()) : null; };
const has = (xml, tag) => new RegExp('<' + tag + '[\\s/>]').test(xml);

// ---------- WPG XML builders ----------
// First authorise on the OWN-3DS branch . Carries additional3DSData +
// <session id>, NO cavv/eci (Worldpay holds the cryptogram).
function buildOwnAuthorise(b) {
  const { merchant, orderCode, amount, currency, card, sessionId, dfReferenceId,
          challengeWindowSize = '390x400', challengePreference = 'noPreference', browser = {} } = b;
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE paymentService PUBLIC "-//WorldPay//DTD WorldPay PaymentService v1//EN"
  "http://dtd.worldpay.com/paymentService_v1.dtd">
<paymentService version="1.4" merchantCode="${esc(merchant)}">
  <submit>
    <order orderCode="${esc(orderCode)}">
      <description>Own-3DS purchase</description>
      <amount value="${esc(amount)}" currencyCode="${esc(currency)}" exponent="2"/>
      <paymentDetails>
        <CARD-SSL>
          <cardNumber>${esc(card.number)}</cardNumber>
          <expiryDate><date month="${esc(card.month)}" year="${esc(card.year)}"/></expiryDate>
          <cardHolderName>${esc(card.name)}</cardHolderName>
          <cvc>${esc(card.cvc)}</cvc>
        </CARD-SSL>
        <session id="${esc(sessionId)}" shopperIPAddress="${esc(browser.ip || '127.0.0.1')}"/>
      </paymentDetails>
      <shopper>
        <browser>
          <acceptHeader>${esc(browser.acceptHeader || 'text/html')}</acceptHeader>
          <userAgentHeader>${esc(browser.userAgentHeader || 'Mozilla/5.0')}</userAgentHeader>
        </browser>
      </shopper>
      <additional3DSData dfReferenceId="${esc(dfReferenceId)}" challengeWindowSize="${esc(challengeWindowSize)}" challengePreference="${esc(challengePreference)}"/>
    </order>
  </submit>
</paymentService>`;
}

// Second authorise after a challenge : completedAuthentication + session id, NO cavv/eci.
function buildFinalAuthorise(b) {
  const { merchant, orderCode, amount, currency, sessionId } = b;
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE paymentService PUBLIC "-//WorldPay//DTD WorldPay PaymentService v1//EN"
  "http://dtd.worldpay.com/paymentService_v1.dtd">
<paymentService version="1.4" merchantCode="${esc(merchant)}">
  <submit>
    <order orderCode="${esc(orderCode)}">
      <description>Own-3DS completion</description>
      <amount value="${esc(amount)}" currencyCode="${esc(currency)}" exponent="2"/>
      <paymentDetails>
        <info3DSecure><completedAuthentication/></info3DSecure>
        <session id="${esc(sessionId)}"/>
      </paymentDetails>
    </order>
  </submit>
</paymentService>`;
}

// EXTERNAL-MPI ("today", golden baseline, : Acme Pay supplies the finished cryptogram.
function buildExternalMpi(b) {
  const { merchant, orderCode, amount, currency, card, mpi = {} } = b;
  return `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE paymentService PUBLIC "-//WorldPay//DTD WorldPay PaymentService v1//EN"
  "http://dtd.worldpay.com/paymentService_v1.dtd">
<paymentService version="1.4" merchantCode="${esc(merchant)}">
  <submit>
    <order orderCode="${esc(orderCode)}">
      <description>External-MPI purchase</description>
      <amount value="${esc(amount)}" currencyCode="${esc(currency)}" exponent="2"/>
      <paymentDetails>
        <CARD-SSL>
          <cardNumber>${esc(card.number)}</cardNumber>
          <expiryDate><date month="${esc(card.month)}" year="${esc(card.year)}"/></expiryDate>
          <cardHolderName>${esc(card.name)}</cardHolderName>
          <cvc>${esc(card.cvc)}</cvc>
        </CARD-SSL>
        <info3DSecure>
          <threeDSVersion>${esc(mpi.version || '2.2.0')}</threeDSVersion>
          <xid>${esc(mpi.xid || '')}</xid>
          <dsTransactionId>${esc(mpi.ds_transaction_id || '')}</dsTransactionId>
          <cavv>${esc(mpi.cavv || '')}</cavv>
          <eci>${esc(mpi.eci || '05')}</eci>
        </info3DSecure>
      </paymentDetails>
    </order>
  </submit>
</paymentService>`;
}

// ---------- built-in MOCK Worldpay WPG ----------
function mockWpgReply(scenario, ctx) {
  const oc = esc(ctx.orderCode);
  if (scenario === 'challenge') {
    const tx = 'sim-3ds-' + crypto.randomUUID().slice(0, 8);
    const acs = `http://localhost:${CFG.port}/acs?ref=${tx}&win=${encodeURIComponent(ctx.challengeWindowSize || '390x400')}`;
    return `<?xml version="1.0"?>
<paymentService version="1.4" merchantCode="${esc(ctx.merchant)}">
  <reply>
    <orderStatus orderCode="${oc}">
      <challengeRequired>
        <threeDSChallengeDetails>
          <transactionId3DS>${tx}</transactionId3DS>
          <threeDSVersion>2.2.0</threeDSVersion>
          <acsURL>${esc(acs)}</acsURL>
          <payload>${b64url('sim-acs-payload-' + tx)}</payload>
        </threeDSChallengeDetails>
      </challengeRequired>
    </orderStatus>
  </reply>
</paymentService>`;
  }
  const refused = scenario === 'refused';
  return `<?xml version="1.0"?>
<paymentService version="1.4" merchantCode="${esc(ctx.merchant)}">
  <reply>
    <orderStatus orderCode="${oc}">
      <payment>
        <paymentMethod>VISA-SSL</paymentMethod>
        <amount value="${esc(ctx.amount)}" currencyCode="${esc(ctx.currency)}" exponent="2"/>
        <lastEvent>${refused ? 'REFUSED' : 'AUTHORISED'}</lastEvent>
        <threeDSVersion>2.2.0</threeDSVersion>
        <transactionId3DS>sim-frictionless-${crypto.randomUUID().slice(0, 8)}</transactionId3DS>
        <paresStatus>${refused ? 'N' : 'Y'}</paresStatus>
      </payment>
    </orderStatus>
  </reply>
</paymentService>`;
}

// ---------- Acme Pay status mapping  ----------
function mapStatus(xml) {
  if (has(xml, 'challengeRequired')) return { status: 'PENDING', sub_status: 'CHALLENGE_REQUIRED' };
  const ev = rx(xml, 'lastEvent');
  if (ev === 'AUTHORISED') return { status: 'SUCCEEDED', sub_status: 'SUCCEEDED_THREE_D_SECURE' };
  if (ev === 'REFUSED')   return { status: 'DECLINED', sub_status: 'AUTHENTICATION_FAILED_THREE_D_SECURE' };
  if (ev === 'ERROR')     return { status: 'ERROR', sub_status: null };
  return { status: 'PENDING', sub_status: null };
}
function threeDSObject(xml) {
  return {
    version: rx(xml, 'threeDSVersion'),
    directory_server_transaction_id: rx(xml, 'transactionId3DS'), // NOT .transaction_id (that's the MPI xid)
    pares_status: rx(xml, 'paresStatus'),
    cryptogram: null,                         // provider-held — intentionally empty
    electronic_commerce_indicator: null,      // provider-held — intentionally empty
  };
}

// ================= JSON / Access Worldpay v7  =================
// Build the CIT/MIT request body. External-MPI 3DS goes in root-level authentication.threeDS.
function buildAccessBody(b) {
  const body = {
    transactionReference: b.transactionReference || ('SIM-' + crypto.randomUUID().slice(0, 8)),
    merchant: { entity: b.entity || ACCESS.entity },
    // channel: REQUIRED on CIT, but FORBIDDEN on MIT (live-verified: MIT 400s "field not allowed")
    ...(b.txnType === 'MIT' ? {} : { channel: b.channel || 'ecom' }),
    instruction: {
      narrative: { line1: b.narrative || 'Acme Pay simulator' },
      value: { currency: b.currency || 'BRL', amount: Number(b.amount) || 1000 },
      paymentInstrument: {
        type: 'card/plain',
        cardNumber: String(b.card.number).replace(/\s/g, ''),
        expiryDate: { month: Number(b.card.month), year: Number(b.card.year) },
        cardHolderName: b.card.name,
        // CVC must be EXCLUDED on MIT (live-verified: "CVC must be excluded for merchant-initiated transactions")
        ...(b.txnType === 'MIT' ? {} : { cvc: b.card.cvc }),
      },
      requestAutoSettlement: { enabled: b.mode === 'PURCHASE' },   // sale vs auth-only
    },
  };
  // External MPI (agnostic 3DS) — the DECIDED approach in .
  if (b.mpi && b.include3ds) {
    body.authentication = { threeDS: {
      version: b.mpi.version || '2.2.0',
      eci: b.mpi.eci || '05',
      authenticationValue: b.mpi.cavv || '',        // Acme Pay Cryptogram -> authenticationValue
      transactionId: b.mpi.ds_transaction_id || '', // Acme Pay DirectoryServerTransactionID -> transactionId
    } };
  }
  // Payfac passthrough — REQUIRED for Payfac entities like DEMOENTITY (Demo Merchant). v7 field names.
  if (b.payfac) {
    body.merchant.paymentFacilitator = {
      schemeId: b.payfac.schemeId || '12345678901',          // 1-11 digits (live v7 rule)
      independentSalesOrganizationId: b.payfac.isoId || '1234567890',
      subMerchant: b.payfac.subMerchant || {
        name: 'Acme Pay Sim SubMerchant', reference: 'SUB001', taxReference: '12345678000199', // reference: 1-15 alphanumeric
        address: { street: 'Av Paulista 1000', city: 'Sao Paulo', state: 'SP', postalCode: '01310100', countryCode: 'BR' },
        phoneNumber: '5511999999999', email: 'submerchant@example.com', url: 'https://example.com',
      },
    };
  }
  // MIT stored credential
  if (b.txnType === 'MIT') {
    body.instruction.customerAgreement = {
      type: b.agreementType || 'subscription',
      storedCardUsage: 'subsequent',
      schemeReference: b.schemeReference || 'SIM-SCHEME-REF',
    };
  } else if (b.storeCredential) {
    body.instruction.customerAgreement = { type: b.agreementType || 'cardOnFile', storedCardUsage: 'first' };
  }
  return body;
}

// Built-in MOCK of Access Worldpay: magic cardHolderName drives the outcome (per PRD test values).
function mockAccessReply(body, txnType) {
  const name = String(body.instruction.paymentInstrument.cardHolderName || '').toUpperCase();
  const paymentId = 'sim-pay-' + crypto.randomUUID().slice(0, 12);
  if (name.startsWith('ERROR')) {
    return { status: 502, body: { errorName: 'bodyDoesNotMatchSchema', message: 'Simulated ERRORED outcome' } };
  }
  if (name.startsWith('REFUSED')) {
    const code = name.replace(/[^0-9]/g, '') || '05';
    const desc = { '51': 'Insufficient funds', '62': 'Restricted card' }[code] || 'Refused';
    return { status: 201, body: { outcome: 'refused', paymentId, refusalCode: code, refusalDescription: desc,
      _links: { 'cardPayments:events': { href: `/api/json/act?rel=events&id=${paymentId}` } } } };
  }
  const settled = body.instruction.requestAutoSettlement && body.instruction.requestAutoSettlement.enabled;
  return { status: 201, body: {
    outcome: settled ? 'sentForSettlement' : 'authorized',
    paymentId,
    scheme: { reference: 'SIM-SCHEME-' + crypto.randomUUID().slice(0, 10) }, // store for MIT
    issuer: { authorizationCode: '' + (100000 + (Date.now() % 899999)) },
    paymentInstrument: { type: 'card/plain+masked', cardBin: deriveBin(body.instruction.paymentInstrument.cardNumber), lastFour: String(body.instruction.paymentInstrument.cardNumber).slice(-4), cardBrand: 'visa' },
    _links: {                                    // HATEOAS — adapter MUST follow these, not build URLs
      'cardPayments:cancel':        { href: `/api/json/act?rel=cancel&id=${paymentId}` },
      'cardPayments:settle':        { href: `/api/json/act?rel=settle&id=${paymentId}` },
      'cardPayments:partialSettle': { href: `/api/json/act?rel=partialSettle&id=${paymentId}` },
      'cardPayments:refund':        { href: `/api/json/act?rel=refund&id=${paymentId}` },
      'cardPayments:events':        { href: `/api/json/act?rel=events&id=${paymentId}` },
    },
  } };
}
function mapAccessStatus(reply) {
  const o = reply.body || {};
  if (reply.status >= 500 || o.errorName) return { status: 'ERROR', detail: o.message || o.errorName };
  const oc = String(o.outcome || '').toLowerCase();
  if (oc === 'authorized') return { status: 'APPROVED', detail: 'authorized (auth-only, capture pending)' };
  if (oc === 'sentforsettlement' || oc === 'sent for settlement') return { status: 'APPROVED', detail: 'authorized + auto-settle queued' };
  if (oc === 'refused') return { status: 'DECLINED', detail: `${o.refusalCode} ${o.refusalDescription}` };
  return { status: 'PENDING', detail: o.outcome || 'unknown' };
}
function postAccess(method, pathOrUrl, bodyObj, creds) {
  return new Promise((resolve, reject) => {
    const base = (creds.env === 'prod' ? ACCESS.prod : ACCESS.sandbox);
    const full = pathOrUrl.startsWith('http') ? pathOrUrl : base + pathOrUrl;
    const u = new URL(full);
    const data = bodyObj ? JSON.stringify(bodyObj) : null;
    const mt = creds.mt || ACCESS.ctype;                       // 3DS uses a different media type
    const auth = Buffer.from(`${creds.username}:${creds.password}`).toString('base64');
    const r = https.request({
      host: u.hostname, path: u.pathname + u.search, method,
      headers: { Authorization: 'Basic ' + auth, 'Content-Type': mt, Accept: mt,
        ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}) },
    }, (res) => { let s = ''; res.on('data', (d) => (s += d)); res.on('end', () => { let p; try { p = JSON.parse(s); } catch { p = { raw: s }; } resolve({ status: res.statusCode, body: p }); }); });
    r.on('error', reject); if (data) r.write(data); r.end();
  });
}

// Native 3DS "verifications" API (live-verified media type + endpoints)
const N3DS_MT = 'application/vnd.worldpay.verifications.customers-v3.hal+json';
const n3ds = (creds, path, body) => postAccess('POST', path, body, { ...creds, mt: N3DS_MT });

// ---------- transport ----------
// POST WPG XML to the sandbox with per-request Basic auth (Merchant C DEMOMERCHANT3D creds)
function postWpg(xml, creds) {
  return new Promise((resolve, reject) => {
    const u = new URL(creds.url || WPG.sandbox);
    const auth = Buffer.from(`${creds.username}:${creds.password}`).toString('base64');
    const r = https.request({
      host: u.hostname, path: u.pathname + u.search, port: u.port || 443, method: 'POST',
      headers: { Authorization: 'Basic ' + auth, 'Content-Type': 'text/xml; charset=utf-8', 'Content-Length': Buffer.byteLength(xml) },
    }, (res) => { let b = ''; res.on('data', (d) => (b += d)); res.on('end', () => resolve({ status: res.statusCode, xml: b })); });
    r.on('error', reject); r.write(xml); r.end();
  });
}
const readBody = (req) => new Promise((res) => { let b = ''; req.on('data', (d) => (b += d)); req.on('end', () => { try { res(b ? JSON.parse(b) : {}); } catch { res({}); } }); });
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };

// ---------- server ----------
const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  try {
    if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/index.html')) {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
    }
    if (req.method === 'GET' && u.pathname === '/api/config') {
      return json(res, 200, {
        mode: CFG.mode, merchant: CFG.merchant, ddcUrl: CFG.ddcUrl,
        hasLiveUrl: !!CFG.url, hasFlexCreds: !!(process.env.THREEDS_FLEX_JWT_MAC_KEY),
        issuer: CFG.issuer, orgUnitId: CFG.orgUnitId,
        access: { sandbox: ACCESS.sandbox, entity: ACCESS.entity, hasCreds: !!(ACCESS.username && ACCESS.password), username: ACCESS.username ? ACCESS.username.slice(0, 6) + '…' : '' },
        cardinal: CARDINAL, jwtAlg: CFG.jwtAlg, wpgSandbox: WPG.sandbox,
      });
    }

    // ===== JSON v7 (Access) — authorise (CIT/MIT), live-capable =====
    if (req.method === 'POST' && u.pathname === '/api/json/authorise') {
      const b = await readBody(req);
      const body = buildAccessBody(b);
      const endpoint = b.txnType === 'MIT'
        ? '/cardPayments/merchantInitiatedTransactions'
        : '/cardPayments/customerInitiatedTransactions';
      const wantLive = b.live && b.username && b.password;
      const reply = wantLive
        ? await postAccess('POST', endpoint, body, { username: b.username, password: b.password, env: b.env })
        : mockAccessReply(body, b.txnType);
      return json(res, 200, {
        live: !!wantLive, endpoint, requestBody: body, response: reply,
        status: mapAccessStatus(reply),
        links: (reply.body && reply.body._links) || null,
        schemeReference: reply.body && reply.body.scheme && reply.body.scheme.reference,
      });
    }

    // ===== JSON v7 — follow a HATEOAS _link (settle / cancel / refund / events) =====
    if (req.method === 'POST' && u.pathname === '/api/json/act') {
      const b = await readBody(req);
      const rel = b.rel || 'settle';
      const wantLive = b.live && b.username && b.password && b.href && b.href.startsWith('http');
      let reply;
      if (wantLive) {
        const method = rel === 'events' ? 'GET' : 'POST';
        // full settle/cancel/refund take NO body; only partial* take a value object (live-verified)
        const isPartial = /partial/i.test(rel);
        const payload = method !== 'POST' ? null : (isPartial && b.amount ? { value: { amount: Number(b.amount), currency: b.currency || 'BRL' } } : null);
        reply = await postAccess(method, b.href, payload, { username: b.username, password: b.password, env: b.env });
      } else {
        // mock: post-auth ops are async 202; the FINAL status arrives via webhook (mTLS).
        // Each webhook event maps to a Acme Pay status; the last event is terminal.
        const timelines = {
          settle:        { ack: 'sentForSettlement', webhooks: [['sentForSettlement', 'PENDING'], ['settled', 'CAPTURED']] },
          partialSettle: { ack: 'sentForSettlement', webhooks: [['sentForSettlement', 'PENDING'], ['settled', 'PARTIALLY_CAPTURED']] },
          refund:        { ack: 'sentForRefund',     webhooks: [['sentForRefund', 'PENDING'], ['refunded', 'REFUNDED']] },
          partialRefund: { ack: 'sentForRefund',     webhooks: [['sentForRefund', 'PENDING'], ['refunded', 'PARTIALLY_REFUNDED']] },
          cancel:        { ack: 'cancelled',         webhooks: [['cancelled', 'CANCELLED']] },
          partialCancel: { ack: 'cancelled',         webhooks: [['cancelled', 'PARTIALLY_CANCELLED']] },
        };
        const tl = timelines[rel];
        if (rel === 'events') {                     // polling fallback: GET current events
          reply = { status: 200, body: { lastEvent: 'settled', events: ['sentForSettlement', 'settled'] } };
        } else if (tl) {
          reply = { status: 202, body: { outcome: tl.ack, note: 'accepted — final status arrives via webhook (mTLS)' },
            webhooks: tl.webhooks.map(([type, acme]) => ({ type, acmeStatus: acme })),
            finalAcmeStatus: tl.webhooks[tl.webhooks.length - 1][1] };
        } else {
          reply = { status: 202, body: { outcome: rel } };
        }
      }
      return json(res, 200, { live: !!wantLive, rel, response: reply, webhooks: reply.webhooks || null, finalAcmeStatus: reply.finalAcmeStatus || null });
    }

    // ===== Native 3DS (Access "verifications" API) — LIVE, -equivalent on JSON =====
    if (req.method === 'POST' && u.pathname === '/api/n3ds/init') {
      const b = await readBody(req);
      const creds = { username: b.username, password: b.password, env: b.env };
      const r = await n3ds(creds, '/verifications/customers/3ds/deviceDataInitialization', {
        transactionReference: b.transactionReference,
        merchant: { entity: b.entity || ACCESS.entity },
        paymentInstrument: { type: 'card/front', cardNumber: String(b.card.number).replace(/\s/g, ''), cardExpiryDate: { month: Number(b.card.month), year: Number(b.card.year) } },
      });
      return json(res, 200, { status: r.status, body: r.body, ddc: r.body.deviceDataCollection || null });
    }
    if (req.method === 'POST' && u.pathname === '/api/n3ds/authenticate') {
      const b = await readBody(req);
      const creds = { username: b.username, password: b.password, env: b.env };
      const r = await n3ds(creds, '/verifications/customers/3ds/authentication', {
        transactionReference: b.transactionReference,
        merchant: { entity: b.entity || ACCESS.entity },
        instruction: { value: { amount: Number(b.amount) || 1000, currency: b.currency || 'BRL' },
          paymentInstrument: { type: 'card/front', cardNumber: String(b.card.number).replace(/\s/g, ''), cardExpiryDate: { month: Number(b.card.month), year: Number(b.card.year) }, cardHolderName: b.card.name } },
        deviceData: { acceptHeader: 'text/html', userAgentHeader: b.userAgent || 'Mozilla/5.0', ...(b.collectionReference ? { collectionReference: b.collectionReference } : {}) },
        challenge: { returnUrl: b.returnUrl || 'http://localhost:' + CFG.port + '/n3ds-return' },
      });
      const acme = { authenticated: 'SUCCEEDED_THREE_D_SECURE', challenged: 'CHALLENGE_REQUIRED', authenticationFailed: 'AUTHENTICATION_FAILED_THREE_D_SECURE' }[r.body.outcome] || r.body.outcome;
      return json(res, 200, { status: r.status, outcome: r.body.outcome, acme_sub_status: acme,
        challenge: r.body.challenge || null, authentication: r.body.authentication || null, body: r.body });
    }
    if (req.method === 'POST' && u.pathname === '/api/n3ds/verify') {
      const b = await readBody(req);
      const creds = { username: b.username, password: b.password, env: b.env };
      const r = await n3ds(creds, '/verifications/customers/3ds/verification', {
        transactionReference: b.transactionReference,
        merchant: { entity: b.entity || ACCESS.entity },
        challenge: { reference: b.reference },
      });
      const a = r.body.authentication || {};
      const acmeStatus = r.body.outcome === 'authenticated' ? 'SUCCEEDED' : (r.body.outcome === 'authenticationFailed' ? 'DECLINED' : 'PENDING');
      return json(res, 200, { status: r.status, outcome: r.body.outcome, acmeStatus,
        three_d_secure: { version: a.version, eci: a.eci, authentication_value: a.authenticationValue, directory_server_transaction_id: a.transactionId }, body: r.body });
    }
    if (req.method === 'POST' && u.pathname === '/n3ds-return') { res.writeHead(200, { 'Content-Type': 'text/html' }); return res.end('<h3>3DS return captured</h3>'); }

    // Mock ACS GET route for the Access lifecycle when demoing (also used by XML side) — see /acs below.

    // 1. Mint DDC JWT (server-side, HS256) + derive BIN
    if (req.method === 'POST' && u.pathname === '/api/mint-jwt') {
      const b = await readBody(req);
      const out = mintJwt({
        issuer: b.issuer || CFG.issuer, orgUnitId: b.orgUnitId || CFG.orgUnitId,
        macKey: b.macKey || CFG.macKey, alg: b.alg || 'HS256', returnUrl: b.returnUrl,
      });
      return json(res, 200, { ...out, bin: deriveBin(b.pan), ddcUrl: CFG.ddcUrl, alg: b.alg || 'HS256' });
    }

    // 3. First authorise (own-3DS or external-MPI)
    if (req.method === 'POST' && u.pathname === '/api/authorise') {
      const b = await readBody(req);
      const orderCode = 'SIM-' + crypto.randomUUID().slice(0, 8);
      const ctx = { ...b, merchant: b.merchant || CFG.merchant, orderCode };
      const wantLive = b.live && b.username && b.password;
      let requestXml, responseXml, live = null;
      if (b.mode === 'EXTERNAL') {
        requestXml = buildExternalMpi(ctx);
        responseXml = wantLive ? (live = await postWpg(requestXml, b)).xml : mockWpgReply(b.scenario === 'refused' ? 'refused' : 'frictionless', ctx);
      } else {
        requestXml = buildOwnAuthorise(ctx);
        // NOTE: live own-3DS needs the 3DS-Flex creds + a real DDC dfReferenceId (B-1). Until then WPG authorises straight through.
        responseXml = wantLive ? (live = await postWpg(requestXml, b)).xml : mockWpgReply(b.scenario || 'frictionless', ctx);
      }
      const challenge = has(responseXml, 'challengeRequired');
      return json(res, 200, {
        orderCode, mode: b.mode, requestXml, responseXml, liveStatus: live && live.status,
        challenge: challenge ? { acsURL: rx(responseXml, 'acsURL'), transactionId3DS: rx(responseXml, 'transactionId3DS'), payload: rx(responseXml, 'payload') } : null,
        status: mapStatus(responseXml), three_d_secure: threeDSObject(responseXml),
      });
    }

    // 4b. Final authorise after challenge completion
    if (req.method === 'POST' && u.pathname === '/api/authorise-final') {
      const b = await readBody(req);
      const ctx = { merchant: b.merchant || CFG.merchant, orderCode: b.orderCode || 'SIM-final', amount: b.amount, currency: b.currency, sessionId: b.sessionId };
      const requestXml = buildFinalAuthorise(ctx);
      const scenario = b.outcome === 'completed' ? 'frictionless' : 'refused';
      const wantLive = b.live && b.username && b.password;
      const responseXml = wantLive ? (await postWpg(requestXml, b)).xml : mockWpgReply(scenario, ctx);
      const mapped = b.outcome === 'completed'
        ? mapStatus(responseXml)
        : (b.outcome === 'canceled' ? { status: 'DECLINED', sub_status: 'CHALLENGE_CANCELED' }
          : b.outcome === 'timeout' ? { status: 'DECLINED', sub_status: 'EXPIRED_TIMEOUT' }
          : { status: 'DECLINED', sub_status: 'AUTHENTICATION_FAILED_THREE_D_SECURE' });
      return json(res, 200, { requestXml, responseXml, status: mapped, three_d_secure: threeDSObject(responseXml) });
    }

    // Mock bank ACS challenge page (rendered in the SDK iframe in the real flow)
    if (req.method === 'GET' && u.pathname === '/acs') {
      const ref = esc(u.searchParams.get('ref') || 'sim');
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end(acsPage(ref));
    }

    json(res, 404, { error: 'not found' });
  } catch (e) {
    json(res, 500, { error: String((e && e.message) || e) });
  }
});

function acsPage(ref) {
  return `<!doctype html><html><head><meta charset="utf-8"><title>Issuer ACS challenge</title>
<style>
  body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#0e1116;color:#e8eaed;display:flex;align-items:center;justify-content:center;height:100vh}
  .card{width:320px;background:#1b1f27;border:1px solid #2a2f3a;border-radius:14px;padding:22px;text-align:center}
  .bank{font-size:12px;letter-spacing:.12em;text-transform:uppercase;color:#8aa0b6;font-weight:700}
  h2{font-size:17px;margin:8px 0 4px} p{font-size:13px;color:#aab4c0;margin:0 0 16px;line-height:1.4}
  input{width:100%;box-sizing:border-box;font-size:20px;letter-spacing:.4em;text-align:center;padding:11px;border-radius:9px;border:1px solid #333b48;background:#11151c;color:#fff;margin-bottom:14px}
  button{width:100%;font-size:14px;font-weight:700;padding:11px;border:none;border-radius:9px;cursor:pointer;margin-bottom:8px}
  .ok{background:#0e7c6b;color:#fff} .bad{background:#2a2f3a;color:#e58479} .to{background:transparent;color:#8aa0b6;font-size:12px}
</style></head><body>
<div class="card">
  <div class="bank">🏦 Banco Simulado · 3-D Secure</div>
  <h2>Verify your payment</h2>
  <p>Enter the one-time code sent to your phone.<br><small>ref ${ref} — hint: 1234 = pass</small></p>
  <input id="otp" inputmode="numeric" maxlength="4" placeholder="––––" autofocus>
  <button class="ok" onclick="done('completed')">Submit</button>
  <button class="bad" onclick="done('failed')">Cancel / wrong code</button>
  <button class="to" onclick="done('timeout')">Simulate timeout</button>
</div>
<script>
  function done(outcome){
    var otp=document.getElementById('otp').value;
    if(outcome==='completed' && otp!=='1234') outcome='failed';
    parent.postMessage({type:'acs-result', outcome:outcome, ref:'${ref}'}, '*');
  }
</script></body></html>`;
}

server.listen(CFG.port, () => {
  console.log(`\n  Worldpay Own-3DS (3DS Flex) simulator — mode=${CFG.mode.toUpperCase()}`);
  console.log(`  → http://localhost:${CFG.port}`);
  console.log(`  merchant=${CFG.merchant}  ddc=${CFG.ddcUrl}`);
  if (CFG.mode === 'live') console.log(`  live url=${CFG.url || '(WORLDPAY_URL not set!)'}\n`);
  else console.log(`  (mock Worldpay WPG + mock bank ACS — no network calls)\n`);
});
