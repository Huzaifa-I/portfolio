# External MPI (Bring-Your-Own 3DS) — Integration Contract

**For:** Paymob engineering
**From:** Acme Pay
**Scope:** Card, customer-initiated transactions (CIT), Direct API V2

This document specifies the behaviour Acme Pay needs in order to route card traffic to Paymob
with Acme Pay acting as the MPI. The accompanying simulator is a runnable implementation of
everything below — where this document and the simulator disagree, the simulator is the
reference.

---

## 0. Where each flow stands

|  | **Native 3DS** — Paymob authenticates | **External 3DS** — Acme Pay authenticates |
|---|---|---|
| **International** (Visa / MC / Amex) | ✅ **Works today.** Verified on a KSA sandbox: challenge issued, redirect served. | ❌ **Not supported.** 8 variants swept, all identical to the control. No field exists. |
| **Mada** (local KSA) | ⚠️ **Untested.** Separate integration ID, never supplied. Redirect vs OTP unknown. | ⚠️ **Untested — and this is the driver.** Majority of KSA volume. |

Native 3DS is not in question and nothing in this document changes it. The ask is the
right-hand column, and the bottom-right cell is the one that matters commercially.

## 1. Background — why this is a build, not a configuration

Acme Pay performs 3DS authentication itself (via Netcetera) and needs to hand the resulting
authentication values to Paymob on the authorisation request, so that Paymob authorises
**without running its own 3DS**.

Acme Pay has tested whether the current Direct API V2 can accept these values. It cannot:

| Market | Integration | Variants attempted | Result |
|---|---|---|---|
| KSA | card integration, `gateway_type: MIGS` | 8 | All byte-identical to the no-MPI control |
| Oman | card | 14 | All ignored or rejected |

The KSA variants covered `source.cavv`/`eci`/`ds_trans_id`, `source.cavv`/`eci`/`xid`, a nested
`source.three_ds_data{}`, a top-level `three_ds{}`, a top-level `authentication{threeDSServerTransID}`,
an MPGS-style `source.authentication_3ds{acsEci,transactionId}`, authentication declared at
intention time, and an explicit `source.is_3d_secure:false` bypass. Every one returned
`pending:true, is_3d_secure:true, success:false` with a `redirection_url` — indistinguishable
from a request carrying no authentication data at all.

Inspection of the full pay-response key list confirms there is **no `cavv` / `eci` / `xid` /
`authentication` / `three_ds*` field on any request or response path**. There is nothing to
enable; the fields do not exist.

This matches Paymob's own statement (13 May 2026) that the flow is not supported for any
merchant or provider. So the ask is a build, and this document is its contract.

---

## 2. The five fields Acme Pay sends

These are produced by the authentication step **before** Acme Pay calls Paymob. They arrive as
plain fields on the authorisation request. There is no callback to Acme Pay, no redirect, and no
dependency on Paymob's 3DS.

**Required:**

| Field | Meaning | Example |
|---|---|---|
| `eci` | Electronic commerce indicator | `"05"` |
| `authentication_value` | CAVV / authentication cryptogram, base64 | `"AAABBJg0VhI0VniQEjRWAAAAAAA="` |
| `ds_transaction_id` | Directory server transaction identifier | `"f38e6948-6d7d-4b0a-9c4a-6f1c9a1f0e21"` |
| `version` | 3DS protocol version | `"2.2.0"` |
| `transaction_status` | Authentication outcome | `"Y"` |

**Optional — accepted, echoed, never required:**

| Field | Meaning | Why it exists |
|---|---|---|
| `three_ds_server_transaction_id` | 3DS **server** transaction id — distinct from the directory-server one | Acme Pay's authentication produces both identifiers. Accept it if useful; a contract carrying only one of the two loses data. |
| `provider` | Label for the MPI that authenticated | Some APIs want to record which MPI produced the values. Included for completeness. |
| `auth_scheme` | Directory server that authenticated (e.g. `MADA`, `VISA`) | Relevant for co-badged cards, where the acquirer may need to know which directory server was used. If your gateway needs it, take it from here rather than inferring it from the BIN. |

### On the shape

External MPI is an established pattern — Acme Pay consumes it across a number of card
integrations today, and the concept is the same everywhere even though the field names and
nesting differ from one API to the next. There is no single industry-standard shape to
conform to.

So the naming below is a **starting point for discussion, not a specification handed down**.
Pick whatever is idiomatic for your platform. **The five values and the five behaviours in §3
are the requirement; the field names are not.**

### Status of each part of this document

Nothing here should be mistaken for a verified contract where it is not one:

| Part | Status |
|---|---|
| The five values in the table above | **Verified** — this is what Acme Pay's authentication produces today |
| Everything Paymob returns today (§1 evidence) | **Verified** on a KSA sandbox, 2026-06-18 |
| Direct Pay card fields (`identifier`, `sourceholder_name`, `cvn`, 2-digit expiry) | **Verified** — accepted, HTTP 200 |
| `payment_keys[0].key` as `payment_token` | **Verified** — `client_secret` returns 401 |
| **`source.three_ds_data` and its response shape (below)** | **Proposed by Acme Pay. Not verified — it cannot be, because no such field exists.** |

Note in particular that a nested `source.three_ds_data{}` was one of the eight variants Acme Pay
attempted, and it was ignored like all the others — so the name below carries no special
status. It is a placeholder to make the shape concrete, nothing more.

Proposed placement — `source.three_ds_data`, alongside the existing Direct Pay source fields:

```json
{
  "payment_token": "<payment_keys[0].key>",
  "source": {
    "identifier": "5123456789012346",
    "sourceholder_name": "Test Cardholder",
    "subtype": "CARD",
    "cvn": "123",
    "expiry_month": "12",
    "expiry_year": "28",
    "three_ds_data": {
      "provider": "netcetera",
      "eci": "05",
      "authentication_value": "AAABBJg0VhI0VniQEjRWAAAAAAA=",
      "ds_transaction_id": "f38e6948-6d7d-4b0a-9c4a-6f1c9a1f0e21",
      "version": "2.2.0",
      "transaction_status": "Y"
    }
  }
}
```

---

## 3. Required behaviours

### B1 — Honour the authentication, skip provider 3DS

When `three_ds_data` is present and valid, authorise directly. Do not issue a challenge.

```
success:         true
pending:         false
is_3d_secure:    false      ← Paymob did not run 3DS; the caller authenticated
redirection_url: null       ← no challenge, no redirect
```

`is_3d_secure:false` here means "Paymob did not perform the authentication," not "the
transaction was unauthenticated." The transaction *is* 3DS-authenticated — by Acme Pay.

### B2 — Echo what was consumed

Return the authentication data that was applied, so Acme Pay can reconcile which authentication
the authorisation actually used:

```json
"three_ds_data_echo": { "provider": "netcetera", "eci": "05", ... }
```

### B3 — Absent data must fail loudly, never fall back silently

If the integration is configured for external MPI and `three_ds_data` is missing, **reject
the request**:

```json
{ "success": false, "error_occured": true, "error_code": "EXTERNAL_MPI_REQUIRED",
  "message": "This integration is configured for external MPI. source.three_ds_data is required." }
```

**In the interest of being straight with you: this is the one item here that asks for more
than the common pattern.** Silently falling back to provider-run 3DS when the authentication
object is missing is normal behaviour across the industry. We are asking you not to, and we
recognise that is a real ask rather than a box to tick.

We ask because we have been burned by the silent fallback more than once. The shape of the
failure is always the same: an authentication value gets dropped somewhere in the chain, the
provider quietly runs its own 3DS instead, and the response looks completely normal. The
misconfiguration stays invisible until it surfaces as timeouts or declines, sometimes weeks
later. A 400 on the very first request would have caught it in minutes.

There is a second reason, specific to this integration. When the values are silently ignored,
an external-MPI request is **indistinguishable from a normal one** — which is exactly the
situation today. It is why establishing that the fields are not consumed took eight request
variants and a full schema inspection, rather than one clear error message. We would like to
not repeat that.

If a hard rejection is unacceptable, the fallback position is an explicit, machine-readable
signal in the response saying the authentication data was not applied. What we cannot work
with is silence.

### B4 — Validation names the offending field

```json
{ "error_code": "EXTERNAL_MPI_INVALID",
  "message": "Missing required field(s): source.three_ds_data.authentication_value" }
```

### B5 — A failed authentication declines; it does not re-challenge

`transaction_status` outside `Y` / `A` must decline cleanly, with no redirect:

```json
{ "success": false, "is_3d_secure": false, "redirection_url": null,
  "error_code": "AUTHENTICATION_FAILED" }
```

---

## 4. Webhooks

An external-MPI authorisation is synchronous — no challenge, no redirect, so the outcome is
already in the Direct Pay response. The webhook is not carrying news. But Acme Pay still
reconciles against it, so three things need to hold. None of them should require a new
webhook type or a new event: the existing transaction callback is the right vehicle.

**W1 — The webhook must not contradict the synchronous response.** If the pay response says
`is_3d_secure: false` and the webhook for the same transaction says `true`, we will normalise
the transaction incorrectly. Whatever B1 returns, the webhook must agree.

**W2 — Carry the same echo.** The webhook should include the same `three_ds_data_echo` as the
authorisation response, for the same reason: so the record shows which authentication was
actually applied, not merely which one was sent.

**W3 — Tell us how the HMAC changes, or that it doesn't.** This is the one that will bite
quietly. Your webhook signature is an HMAC-SHA512 computed over a fixed, ordered
concatenation of transaction fields. If external-MPI data enters that string, we need the
exact field list **and its position in the order** — a signature we compute in a different
order than you do fails as an invalid signature, with nothing to indicate why. If the new
fields stay out of the HMAC, please say so explicitly; "unchanged" is a perfectly good answer,
we just need it in writing rather than inferred.

To be clear about scope: we are not asking for a webhook redesign. W1 and W2 likely fall out
of the B1/B2 implementation for free, and W3 may well be a one-line answer.

## 5. Enablement

External MPI should be a **per-integration-ID** setting. When it is on, provider-run 3DS is
off for that integration and B3 applies. Acme Pay needs the ability to confirm the flag state on
a sandbox integration before testing, because a flag that is silently off is
indistinguishable from a feature that does not work — we have lost time to exactly this with
another provider.

---

## 6. Explicitly out of scope

**Merchant-initiated transactions, tokenisation, and recurring are not in this phase.** Acme Pay
will send CITs only. This is deliberate: Mada network transaction IDs are provider-assigned
rather than portable, so cross-provider MIT orchestration is not possible for Mada regardless
of what Paymob builds here. Please do not scope MIT work off the back of this document — it
would not be consumed.

---

## 7. Mada — the open cell

Everything in §1–§3 was established against the **card (`MIGS`) integration**, which handles
Visa/Mastercard/Amex. **Mada has never been tested at all** — neither native nor external —
because it runs on a separate integration ID that has not been supplied.

This matters more than the international case. Mada is the majority of this merchant's KSA
volume, so an external-MPI build that covers only international cards does not solve the
problem it was commissioned for.

Three things are unresolved, and one of them is Acme Pay's, not Paymob's:

**a. No Mada integration ID.** Paymob-side. Without it the sweep cannot be re-run and the
Mada purchase response shape cannot be captured.

**b. No Mada-eligible test PAN.** Paymob-side. The MIGS test PAN will not pass a Mada BIN.

**c. No Mada test PAN in Acme Pay's own 3DS sandbox.** Acme Pay-side, and narrower than it first
looks — the distinction matters:

- Acme Pay's 3DS provider is **MADA-compliant at scheme level**, so our authentication side is
  *not* the blocker.
- But its **sandbox simulator** publishes test cards for **Visa, Mastercard, Amex, Diners and
  JCB only**. No Mada PAN.

So on our side the gap is test fixtures, not capability. It does not block your build — the
contract in §3 is brand-agnostic — but it does affect how an end-to-end sandbox result gets
validated, and it belongs on the table when timelines are discussed.

**One open question for Paymob:** is Mada's native response a 3DS redirect like Visa/MC, or
an OTP relay (as OmanNet is)? The working hypothesis is a redirect, since SAMA mandates 3DS
for Mada e-commerce — but that is a hypothesis, not a finding, and it changes the adapter.

## 8. What Acme Pay still needs from Paymob

| # | Item | Why |
|---|---|---|
| 1 | **Mada integration ID** (sandbox) | The tested integration is card/`MIGS`. Mada is the majority of KSA volume and has never been exercised. Both the native capture and the MPI sweep must be re-run against it. |
| 2 | **Mada-eligible test PAN** | The MIGS test PAN will not pass a Mada BIN. |
| 3 | **Mada native response shape** | Redirect or OTP relay? Drives the adapter. |
| 4 | **`hmac_secret`** | Webhook signature verification. |
| 5 | **Whether external-MPI fields enter the HMAC string** — and if so, their position in the order | §4 / W3. A one-line answer either way; an unstated change fails as an invalid signature with nothing to indicate why. |
| 6 | **Written confirmation** of the external-MPI decision and target date | Currently blocking Acme Pay's own scoping. |

---

## 9. Verifying against this document

```bash
node paymob-3ds-simulator/server.js
# → http://localhost:4111
```

The mock implements B1–B5 and is curl-able directly at
`POST /mock/api/acceptance/payments/pay`. Point the simulator's live mode at a Paymob sandbox
with your own credentials and run the same request both ways — the two columns show today's
behaviour against the target, field by field.
