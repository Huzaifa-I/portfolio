#!/usr/bin/env node
/**
 * Paymob 3DS Simulator — native 3DS vs external 3DS (MPI), international vs Mada.
 * Zero dependencies.
 *
 * Two flows:
 *   NATIVE   — Paymob runs 3DS. Works today. Verified on a KSA sandbox 2026-06-18.
 *              Returns pending:true, is_3d_secure:true and a redirection_url.
 *   EXTERNAL — Acme Pay runs 3DS (via Netcetera) and hands Paymob the finished
 *              authentication values. Paymob authorises without challenging.
 *              Does not exist today — this is the ask. See SPEC.md.
 *
 * Two targets:
 *   MOCK — reference implementation. For NATIVE it mirrors what Paymob already does,
 *          so mock and live agree. For EXTERNAL it implements SPEC.md B1–B5, so mock
 *          and live diverge. That divergence is the entire point of this tool.
 *   LIVE — a real Paymob host, using YOUR OWN sandbox credentials. Nothing is
 *          hardcoded, nothing is persisted, nothing is logged.
 *
 *   node paymob-3ds-simulator/server.js   →  http://localhost:4111
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const crypto = require('crypto');

const PORT = process.env.PORT || 4111;
const DEFAULT_HOST = process.env.PAYMOB_HOST || 'ksa.paymob.com';
// Acme Pay — where real Step 1 (3DS Standalone authentication) runs.
const ACME_HOST = process.env.ACME_HOST || 'acmepay.example';
// Optional server-side credentials. When set, the tool runs real Step 1 WITHOUT anyone
// pasting keys in the UI — they stay in this process's env, never sent to the browser and
// never in the shared package. Run with:
//   ACME_PUB=sandbox_… ACME_PRIV=… ACME_ACCT=… node server.js
const ACME_PUB = process.env.ACME_PUB || '';
const ACME_PRIV = process.env.ACME_PRIV || '';
const ACME_ACCT = process.env.ACME_ACCT || '';
// Default 3DS connection (3ds_connection metadata) for international/Path 1. On this account,
// naming any connection routes standalone 3DS to Netcetera, which is what international needs.
// Mada/Path 2 (Checkout) overrides per request. Callers can still pass their own `connection`.
const ACME_CONN = process.env.ACME_3DS_CONNECTION || '';

// A SHAREABLE access key — this is what you give Paymob. It gates the real-3DS endpoints
// but reveals NOTHING about the Acme Pay keys (those never leave this server). Set it alongside
// the Acme Pay keys and host the tool; hand Paymob the URL + this token, not the Acme Pay keys.
//   ACME_PUB=… ACME_PRIV=… ACME_ACCT=… SHARE_TOKEN=some-long-random-string node server.js
const SHARE_TOKEN = process.env.SHARE_TOKEN || '';

// ===========================================================================
// PRODUCTION MODE + PER-PROVIDER LOGIN  (OFF by default — see PRODUCTION-PLAN.md)
// ---------------------------------------------------------------------------
// AUTH_MODE:
//   'token'     (default) — single shared access key (SHARE_TOKEN). Sandbox sharing.
//   'providers'           — each provider (Paymob, …) logs in with username + password;
//                           the server issues a short-lived signed session and resolves
//                           that provider's OWN Acme Pay account/keys. Card data is never
//                           stored or logged; the provider enters real PANs in the UI.
// PROD_MODE=1 defaults AUTH_MODE to 'providers', flips the default rails to production,
// and restricts real authentication to Visa/Mastercard (Mada excluded by scope/cost).
// ---------------------------------------------------------------------------
const PROD_MODE = process.env.PROD_MODE === '1';
const AUTH_MODE = process.env.AUTH_MODE || (PROD_MODE ? 'providers' : 'token');
const SESSION_SECRET = process.env.SESSION_SECRET || '';           // HMAC key for sessions
const SESSION_TTL_MIN = Number(process.env.SESSION_TTL_MIN || 120); // login lifetime
const PROVIDERS_FILE = process.env.PROVIDERS_FILE || path.join(__dirname, 'providers.local.json');

// Provider registry: { "<username>": { pw:"salt$iter$hexhash", label, host, account_id,
//   acme_pub, acme_priv, connection, schemes:["visa","mastercard"] } }. Never committed.
let PROVIDERS = {};
function loadProviders() {
  try { if (fs.existsSync(PROVIDERS_FILE)) PROVIDERS = JSON.parse(fs.readFileSync(PROVIDERS_FILE, 'utf8')); }
  catch (e) { console.error('providers file parse error:', e.message); PROVIDERS = {}; }
}
if (AUTH_MODE === 'providers') loadProviders();

// Password check — PBKDF2-SHA256, constant-time. Stored as "salt$iterations$hexhash"
// (generate with scripts/hash-password.js). Never logs the password.
function verifyPassword(password, rec) {
  if (!rec || !rec.pw) return false;
  const [salt, iter, hash] = String(rec.pw).split('$');
  if (!salt || !iter || !hash) return false;
  const test = crypto.pbkdf2Sync(String(password), salt, Number(iter), 32, 'sha256').toString('hex');
  const a = Buffer.from(test), bb = Buffer.from(hash);
  return a.length === bb.length && crypto.timingSafeEqual(a, bb);
}

// Signed, expiring session token: base64url(payload).hmac. Stateless — no server session store.
function signSession(provider) {
  const payload = Buffer.from(JSON.stringify({ p: provider, exp: Date.now() + SESSION_TTL_MIN * 60000 })).toString('base64url');
  const sig = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  return payload + '.' + sig;
}
function verifySession(tok) {
  if (!tok || !SESSION_SECRET) return null;
  const [payload, sig] = String(tok).split('.');
  if (!payload || !sig) return null;
  const expect = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  if (sig.length !== expect.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expect))) return null;
  let d; try { d = JSON.parse(Buffer.from(payload, 'base64url').toString()); } catch { return null; }
  if (!d.exp || Date.now() > d.exp || !PROVIDERS[d.p]) return null;
  return d.p;
}

// Unified auth: returns { ok, provider }. In 'providers' mode a valid session is required;
// in 'token' mode the shared SHARE_TOKEN gate applies (current sandbox behavior).
function authContext(req, b) {
  if (AUTH_MODE === 'providers') {
    const tok = (b && b.session) || req.headers['x-session'] || '';
    const provider = verifySession(tok);
    return provider ? { ok: true, provider } : { ok: false, provider: null };
  }
  if (!SHARE_TOKEN) return { ok: true, provider: null };
  const t = (b && b.share_token) || req.headers['x-share-token'] || '';
  return { ok: t === SHARE_TOKEN, provider: null };
}
// Back-compat shim for existing call sites (token mode only).
function tokenOK(req, b) { return authContext(req, b).ok; }

// Resolve creds/account/host. In 'providers' mode use THAT provider's own Acme Pay account;
// otherwise fall back to UI-entered keys or the server env (current behavior).
function resolveAcme(b, provider) {
  if (provider && PROVIDERS[provider]) {
    const P = PROVIDERS[provider];
    return {
      creds: { public_key: P.acme_pub, private_key: P.acme_priv },
      account_id: P.account_id, host: P.host || ACME_HOST,
      connection: P.connection || ACME_CONN,
      schemes: (P.schemes || ['visa', 'mastercard']).map((s) => s.toLowerCase()),
    };
  }
  const creds = (b.creds && b.creds.private_key)
    ? b.creds
    : { public_key: ACME_PUB, private_key: ACME_PRIV };
  return { creds, account_id: b.account_id || ACME_ACCT, host: b.host || ACME_HOST };
}

// The five authentication values Acme Pay's MPI produces. See SPEC.md §2.
const MPI_REQUIRED = [
  'eci',                   // electronic commerce indicator
  'authentication_value',  // CAVV, base64
  'ds_transaction_id',     // directory server transaction id
  'version',               // 3DS protocol version
  'transaction_status',    // authentication outcome
];

// Accepted but never required. `three_ds_server_transaction_id` is worth taking: Acme Pay's
// authentication produces both a 3DS-server transaction id and a directory-server one, and a
// contract carrying only one of the two loses data.
const MPI_OPTIONAL = [
  'provider',                      // label for the MPI that authenticated
  'three_ds_server_transaction_id',// 3DS server txn id — distinct from ds_transaction_id
  'auth_scheme',                   // directory server that authenticated (e.g. MADA / VISA)
];

// ---------------------------------------------------------------------------
// Request builders — identical for MOCK and LIVE so the comparison is honest
// ---------------------------------------------------------------------------

// VERIFIED on a KSA sandbox (2026-06-18): amount / currency / payment_methods /
// billing_data{first_name,last_name,email,phone_number} → HTTP 201.
function buildIntention(b) {
  return {
    amount: b.amount,
    currency: b.currency,
    payment_methods: [Number(b.integration_id)],
    billing_data: {
      first_name: b.billing.first_name,
      last_name: b.billing.last_name,
      email: b.billing.email,
      phone_number: b.billing.phone_number,
    },
    notification_url: b.notification_url || 'https://example.com/webhook',
    redirection_url: b.redirection_url || 'https://example.com/return',
    items: [],
  };
}

// VERIFIED on a KSA sandbox (2026-06-18): source.identifier (PAN),
// source.sourceholder_name (full name), source.cvn and a 2-digit expiry were all
// accepted on Direct Pay → HTTP 200. NOT source.pan / cardholder_first_name.
//
// ASSUMED, not verified — flagged so they are not mistaken for evidence:
//   * subtype: 'CARD'  — subtype exists (TOKEN and APPLE_PAY are documented) but the
//                        CARD value was never isolated in a capture.
//   * expiry_month     — only `expiry_year` was quoted verbatim from the Postman
//                        collection; the month field name is inferred by symmetry.
function buildSource(b) {
  const s = {
    identifier: String(b.card.number).replace(/\s/g, ''),
    sourceholder_name: b.card.name,
    subtype: b.subtype || 'CARD',
    cvn: b.card.cvn,
    expiry_month: b.card.expiry_month,
    expiry_year: b.card.expiry_year, // 2-digit on Direct Pay, 4-digit on Platform Payments
  };
  // Only the external flow carries authentication data. The native flow's request is
  // deliberately identical minus this key — that is what makes them comparable.
  if (b.flow === 'external' && b.mpi) s.three_ds_data = b.mpi;
  return s;
}

// ---------------------------------------------------------------------------
// MOCK
// ---------------------------------------------------------------------------
const mockOrders = new Map();
let mockSeq = 8100000;

function mockIntention(body) {
  if (!body.payment_methods || !body.payment_methods.length) {
    return { status: 400, body: { detail: 'payment_methods must contain an integration id' } };
  }
  const id = ++mockSeq;
  const key = 'MOCK.' + Buffer.from(`${id}:${body.amount}:${body.currency}`).toString('base64url');
  mockOrders.set(key, { order_id: id, amount: body.amount, currency: body.currency });
  return {
    status: 201,
    body: {
      id,
      client_secret: 'mock_csk_' + id,
      payment_keys: [{ key, integration: body.payment_methods[0] }],
      gateway_type: 'MIGS',
      order_id: id,
    },
  };
}

function mockPay(body, flow) {
  const order = mockOrders.get(body.payment_token);
  if (!order) {
    // Mirrors the real API: client_secret is NOT accepted here, payment_keys[0].key is.
    return { status: 401, body: { detail: 'Invalid payment_token. Use payment_keys[0].key.' } };
  }
  const src = body.source || {};
  const mpi = src.three_ds_data;

  const base = {
    id: order.order_id,
    order: { id: order.order_id },
    amount_cents: order.amount,
    currency: order.currency,
    is_capture: false,
  };

  // ---- NATIVE: reproduce what Paymob already does today ----
  // Verified shape: pending:true, is_3d_secure:true, success:false + redirection_url.
  if (flow === 'native') {
    return {
      status: 200,
      body: {
        ...base,
        success: false,
        pending: true,
        is_3d_secure: true,
        is_auth: false,
        error_occured: false,
        redirection_url:
          'https://' + DEFAULT_HOST + '/api/acceptance/post_pay?id=' + order.order_id,
        message: 'Cardholder must complete the 3DS challenge at redirection_url.',
      },
    };
  }

  // ---- EXTERNAL: SPEC.md B1–B5 ----

  // B3 — absent authentication data must fail loudly, never fall back silently.
  if (!mpi) {
    return {
      status: 400,
      body: {
        ...base,
        success: false,
        pending: false,
        error_occured: true,
        error_code: 'EXTERNAL_MPI_REQUIRED',
        message:
          'This integration is configured for external MPI. source.three_ds_data is required. ' +
          'Provider-run 3DS is disabled for this integration.',
      },
    };
  }

  // B4 — validation names the offending field.
  const missing = MPI_REQUIRED.filter((f) => !mpi[f]);
  if (missing.length) {
    return {
      status: 400,
      body: {
        ...base,
        success: false,
        pending: false,
        error_occured: true,
        error_code: 'EXTERNAL_MPI_INVALID',
        message: `Missing required field(s): ${missing.map((m) => `source.three_ds_data.${m}`).join(', ')}`,
      },
    };
  }

  // B5 — a failed authentication declines; it does not re-challenge.
  if (!['Y', 'A'].includes(String(mpi.transaction_status).toUpperCase())) {
    return {
      status: 200,
      body: {
        ...base,
        success: false,
        pending: false,
        is_3d_secure: false,
        redirection_url: null,
        error_occured: true,
        error_code: 'AUTHENTICATION_FAILED',
        message: `transaction_status=${mpi.transaction_status} is not an approved authentication.`,
        three_ds_data_echo: mpi,
      },
    };
  }

  // B1 + B2 — honour the external authentication, skip our own 3DS, echo it back.
  // The echo carries only fields the contract recognises; anything else is reported as
  // ignored rather than silently swallowed, so Acme Pay can tell what was actually applied.
  const known = [...MPI_REQUIRED, ...MPI_OPTIONAL];
  const echo = {};
  known.forEach((k) => { if (mpi[k] !== undefined) echo[k] = mpi[k]; });
  const ignored = Object.keys(mpi).filter((k) => !known.includes(k));

  return {
    status: 200,
    body: {
      ...base,
      success: true,
      pending: false,
      is_3d_secure: false,   // Paymob did NOT run 3DS — the caller authenticated
      redirection_url: null, // no challenge, no redirect
      is_auth: true,
      error_occured: false,
      three_ds_data_echo: echo,
      ...(ignored.length ? { three_ds_data_ignored: ignored } : {}),
      source_data: { pan: String(src.identifier || '').slice(-4), sub_type: src.subtype, type: 'card' },
    },
  };
}

// ---------------------------------------------------------------------------
// LIVE
// ---------------------------------------------------------------------------
function live(host, method, pathname, headers, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const req = https.request(
      {
        host, path: pathname, method,
        headers: {
          'Content-Type': 'application/json',
          ...headers,
          ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
        },
      },
      (res) => {
        let buf = '';
        res.on('data', (d) => (buf += d));
        res.on('end', () => {
          let parsed;
          try { parsed = JSON.parse(buf); } catch { parsed = { raw: buf.slice(0, 2000) }; }
          resolve({ status: res.statusCode, body: parsed });
        });
      }
    );
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

// ---------------------------------------------------------------------------
// Mada support for the API path (parity with the UI).
// BIN list supplied by the Mada scheme (6- and 8-digit prefixes). The contract fields are
// pure EMV, and production CAVV validation happens between Paymob's acquiring and the real
// Mada DS — no sandbox cryptogram validates there — so simulated values are legitimate for
// contract testing and are ALWAYS labeled as such.
// ---------------------------------------------------------------------------
const MADA_BINS = ('403024 406136 406996 407520 409201 410621 410685 410834 412565 417633 419593 420132 ' +
  '421141 422817 422818 422819 428331 428671 428672 428673 431361 432328 434107 439954 440533 440647 ' +
  '440795 442463 445564 445696 446393 446404 446672 455036 455708 457865 457997 458456 462220 468540 ' +
  '468541 468542 468543 474491 483010 483011 483012 484783 486094 486095 486096 489318 489319 492464 ' +
  '504300 513213 515079 516138 520058 521076 524130 524514 524940 529415 529741 530060 531196 535825 ' +
  '535989 536023 537767 543085 543357 549760 554180 555610 558563 588845 588848 588850 604906 636120 ' +
  '968201 968202 968203 968204 968205 968206 968207 968208 968209 968211 968212 ' +
  '22337902 22337986 22402030 40177800 40545400 40719700 40728100 40739500 42222200 42403275 44661731 ' +
  '44661833 45488707 45488708 45488713 45488725 45488726 45488727 45488729 45501701 45501703 45501705 ' +
  '49098000 49098001 49506693 50696811 50696812 50696813 50696814 50696815 50696816 50696817 50696818 ' +
  '50696819 50696820 50696821 50696822 50696823 50696824 50696825 50696826 50696827 50696828 50696845 ' +
  '50696847 50696848 52166100 53670801 53973776').split(' ');
const isMadaBin = (pan) => MADA_BINS.some((b) => pan.startsWith(b));

// Card scheme from PAN (for the production Visa/Mastercard-only guard).
function cardScheme(pan) {
  if (/^4/.test(pan)) return 'visa';
  if (/^5[1-5]/.test(pan) || /^2(2[2-9]\d|[3-6]\d\d|7[01]\d|720)/.test(pan)) return 'mastercard';
  if (/^3[47]/.test(pan)) return 'amex';
  return 'other';
}
// In production, real authentication is scoped to Visa/Mastercard (Mada excluded by cost/
// scope — it is validated in the production pilot via the acquiring bank, not this setup).
// Returns an error string if the card is out of scope, else null. Never logs the PAN.
function prodSchemeGuard(pan, schemes) {
  if (!PROD_MODE) return null;
  const allowed = (schemes || ['visa', 'mastercard']).map((s) => s.toLowerCase());
  if (isMadaBin(pan) || !allowed.includes(cardScheme(pan))) {
    return 'Production scope is Visa and Mastercard. Mada (and other schemes) are validated in ' +
      'the production pilot via your acquiring bank — not in this authentication setup.';
  }
  return null;
}

function simulatedMadaValues() {
  return {
    eci: '05',
    authentication_value: crypto.randomBytes(20).toString('base64'),
    ds_transaction_id: crypto.randomUUID(),
    three_ds_server_transaction_id: crypto.randomUUID(),
    version: '2.2.0',
    transaction_status: 'Y',
    auth_scheme: 'MADA',
    provider: 'SIMULATED_MADA_DS',
  };
}
const SIMULATED_MADA_NOTE =
  'SIMULATED Mada DS values — well-formed EMV, not network-authenticated. No sandbox ' +
  'cryptogram (from any test environment) validates against the production Mada DS; these ' +
  'prove the contract and flow, which is what an external-MPI build consumes.';

// ---------------------------------------------------------------------------
// ACS OTP relay — lets the simulator collect the OTP in its own UI.
// The sandbox ACS rejects browser-framed requests (403/406 WAF) but accepts
// server-side POSTs, so the server drives the challenge: POST the CReq, parse
// the returned form (hidden fields + cookies), then replay the user's OTP.
// ---------------------------------------------------------------------------
const acsSessions = new Map();

function httpForm(urlStr, headers, bodyStr) {
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr);
    const req = https.request(
      {
        host: u.host, path: u.pathname + u.search, method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'Content-Length': Buffer.byteLength(bodyStr),
          ...headers,
        },
      },
      (r) => {
        let buf = '';
        r.on('data', (d) => (buf += d));
        r.on('end', () => resolve({
          status: r.statusCode,
          cookies: r.headers['set-cookie'] || [],
          location: r.headers.location || null,
          body: buf,
        }));
      }
    );
    req.on('error', reject);
    req.write(bodyStr);
    req.end();
  });
}

function parseAcsForm(html, baseUrl) {
  const form = /<form[^>]*action="([^"]*)"[^>]*>/i.exec(html);
  const action = form ? new URL(form[1], baseUrl).toString() : null;
  const fields = {};
  const re = /<input[^>]*>/gi;
  let m;
  while ((m = re.exec(html))) {
    const tag = m[0];
    const name = (/name="([^"]*)"/i.exec(tag) || [])[1];
    const value = (/value="([^"]*)"/i.exec(tag) || [])[1] || '';
    const type = (/type="([^"]*)"/i.exec(tag) || [])[1] || 'text';
    if (name && type !== 'checkbox' && name !== 'otp') fields[name] = value;
  }
  return { action, fields };
}

// ===========================================================================
// REAL STEP 1 — Acme Pay 3DS Standalone authentication (produces real values)
// ---------------------------------------------------------------------------
// Docs: https://docs.acmepay.example/docs/basic-concepts/3ds-1
//   POST /v1/three-d-secure/setups   → setup_id + collect_url (device data)
//   POST /v1/payments  (metadata 3DS_ONLY:1)  → authenticate only, no charge
//   GET  /v1/payments/{id}           → poll for the challenge outcome
// The private-secret-key is held per-request and never logged or persisted.
// ---------------------------------------------------------------------------

function acme(host, creds, method, pathname, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const req = https.request(
      {
        host: host || ACME_HOST, path: pathname, method,
        headers: {
          'Content-Type': 'application/json',
          'X-idempotency-key': crypto.randomUUID(),
          'public-api-key': creds.public_key || '',
          'private-secret-key': creds.private_key || '',
          ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
        },
      },
      (r) => {
        let buf = '';
        r.on('data', (d) => (buf += d));
        r.on('end', () => {
          let parsed;
          try { parsed = JSON.parse(buf); } catch { parsed = { raw: buf.slice(0, 2000) }; }
          resolve({ status: r.statusCode, body: parsed });
        });
      }
    );
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

const acmeCard = (c) => ({
  holder_name: c.name,
  number: String(c.number).replace(/\s/g, ''),
  expiration_month: Number(c.expiry_month),
  expiration_year: Number(c.expiry_year) < 100 ? 2000 + Number(c.expiry_year) : Number(c.expiry_year),
  security_code: c.cvn,
});

// Pull the five+1 canonical values out of a Acme Pay payment, wherever the 3DS block sits.
// The response nests it differently inline vs. in the webhook, so search a few paths.
const PROVIDER_LABEL = {
  NETCETERA_3DS: 'netcetera',
  CHECKOUT_COM_3DS: 'checkout.com',
  CYBERSOURCE_3DS: 'cybersource',
};

function extractThreeDS(paymentBody, providerId) {
  // Acme Pay nests the 3DS block in several places depending on the response shape:
  //   payment_method.payment_method_detail.card.card_data.three_d_secure
  //   transactions.payment_method.detail.card.card_data.three_d_secure   (object OR array)
  // Rather than hardcode every path, recursively find the first three_d_secure object that
  // actually carries an ECI or cryptogram.
  function find(o) {
    if (!o || typeof o !== 'object') return null;
    if (o.three_d_secure && typeof o.three_d_secure === 'object' &&
        (o.three_d_secure.electronic_commerce_indicator || o.three_d_secure.cryptogram)) {
      return o.three_d_secure;
    }
    for (const k of Object.keys(o)) {
      const hit = find(o[k]);
      if (hit) return hit;
    }
    return null;
  }
  const t = find(paymentBody);
  if (!t) return null;
  // Map Acme Pay's field names → the canonical MPI values the Paymob step consumes.
  const mpi = {};
  if (t.electronic_commerce_indicator) mpi.eci = t.electronic_commerce_indicator;
  if (t.cryptogram) mpi.authentication_value = t.cryptogram;
  if (t.directory_server_transaction_id) mpi.ds_transaction_id = t.directory_server_transaction_id;
  if (t.transaction_id) mpi.three_ds_server_transaction_id = t.transaction_id;
  if (t.version) mpi.version = t.version;
  if (t.pares_status) mpi.transaction_status = t.pares_status;
  // Label reflects whichever 3DS provider actually ran (Netcetera / Checkout / Cybersource),
  // not a hardcoded assumption.
  mpi.provider = PROVIDER_LABEL[providerId] || (providerId ? String(providerId).toLowerCase() : 'netcetera');
  return { mpi, raw: t };
}

// Classify a payment response: verified (values ready) / challenge (needs OTP) / other.
function classifyAcmePayment(pay) {
  const b = (pay && pay.body) || {};
  const status = String(b.status || '').toUpperCase();
  const sub = String(b.sub_status || '').toUpperCase();
  // The challenge page URL is NOT at checkout.redirect_url (that object only carries
  // session + sdk_action_required). The browser-renderable challenge page lives at
  // payment_method.payment_method_detail.card.redirect_url (checkout.sandbox.acmepay.example/payment
  // ?session=…&3ds=true) — hunt for it across the known locations.
  const cardRedirect = (o) => {
    try {
      const d = o.payment_method_detail || o.detail;
      return d && d.card && d.card.redirect_url;
    } catch (e) { return null; }
  };
  const redirect_url =
    (b.checkout && b.checkout.redirect_url) ||
    b.redirect_url ||
    (b.payment_method && cardRedirect(b.payment_method)) ||
    (b.transactions && !Array.isArray(b.transactions) && b.transactions.payment_method &&
      cardRedirect(b.transactions.payment_method)) ||
    null;
  // Direct ACS challenge: Netcetera returns acsURL + a ready-made base64 CReq. POSTing
  // creq=<that> into an iframe renders the OTP page embedded (EMVCo browser flow) — unlike
  // the hosted checkout page, which sends 403 when framed cross-origin.
  const acs = (() => {
    try {
      const t = !Array.isArray(b.transactions) ? b.transactions : b.transactions[0];
      const rr = t && t.provider_data && t.provider_data.raw_response;
      return (rr && rr.acsURL && rr.base64EncodedChallengeRequest)
        ? { url: rr.acsURL, creq: rr.base64EncodedChallengeRequest } : null;
    } catch (e) { return null; }
  })();
  if (status === 'SUCCEEDED' || sub === 'THREE_D_SECURE_VERIFIED') return { state: 'verified' };
  if (status === 'PENDING' || sub === 'WAITING_ADDITIONAL_STEP' || redirect_url) {
    return { state: 'challenge', payment_id: b.id, redirect_url, acs };
  }
  return { state: 'other', status: b.status, sub_status: b.sub_status };
}

// ---------------------------------------------------------------------------
// Verdict — computed from the response, never asserted
// ---------------------------------------------------------------------------
function verdict(pay, sentMpi, flow) {
  const b = (pay && pay.body) || {};
  const challenged = b.is_3d_secure === true || !!b.redirection_url || b.pending === true;

  if (flow === 'native') {
    return challenged
      ? { state: 'native', label: 'Native 3DS — challenge issued',
          detail: 'Paymob ran its own 3DS and returned a redirection_url for the cardholder. ' +
                  'This is the flow that works today, and it is the correct behaviour here.' }
      : { state: 'other', label: 'No challenge issued',
          detail: b.message || b.detail || 'Expected a provider 3DS redirect. See raw response.' };
  }

  if (!sentMpi) {
    if (b.error_code === 'EXTERNAL_MPI_REQUIRED') {
      return { state: 'control', label: 'Control — correctly rejected',
        detail: 'No authentication data was sent, so the request was refused outright rather than ' +
                'falling back to provider-run 3DS. This is the target behaviour (spec B3).' };
    }
    return { state: 'control', label: 'Control — no MPI sent',
      detail: challenged
        ? 'Provider ran its own 3DS. This is the baseline the MPI request must differ from — ' +
          'if it does not, the fields were ignored.'
        : 'No provider 3DS challenge was issued.' };
  }

  if (challenged) {
    return { state: 'ignored', label: 'MPI IGNORED — provider 3DS forced',
      detail: 'Authentication data was sent, and the response is indistinguishable from the ' +
              'no-MPI control: is_3d_secure=true with a redirection_url. The fields were not consumed.' };
  }
  if (b.success === true && b.is_3d_secure === false) {
    return { state: 'honored', label: 'MPI HONOURED — authorised without provider 3DS',
      detail: 'is_3d_secure=false, no redirection_url, success=true. This is the target behaviour.' };
  }
  return { state: 'other', label: 'Declined / error',
    detail: b.message || b.detail || 'See raw response.' };
}

// ---------------------------------------------------------------------------
// HTTP
// ---------------------------------------------------------------------------
const readBody = (req) =>
  new Promise((resolve) => {
    let b = '';
    req.on('data', (d) => (b += d));
    req.on('end', () => { try { resolve(b ? JSON.parse(b) : {}); } catch { resolve({}); } });
  });

// Luhn check — only mask true card numbers, not random 13-19 digit ids.
function luhnOk(s) {
  let sum = 0, alt = false;
  for (let i = s.length - 1; i >= 0; i--) {
    let d = s.charCodeAt(i) - 48; if (d < 0 || d > 9) return false;
    if (alt) { d *= 2; if (d > 9) d -= 9; }
    sum += d; alt = !alt;
  }
  return sum % 10 === 0;
}
// Production defense-in-depth: mask any full PAN (Luhn-valid 13–19 digits) in outbound
// JSON to first6+last4, so no response ever carries a full PAN (even back to its sender).
function redactPANs(str) {
  return str.replace(/\d{13,19}/g, (m) => (luhnOk(m) ? m.slice(0, 6) + '*'.repeat(m.length - 10) + m.slice(-4) : m));
}
const json = (res, code, obj) => {
  res.writeHead(code, { 'Content-Type': 'application/json' });
  let body = JSON.stringify(obj, null, 2);
  if (PROD_MODE) body = redactPANs(body);
  res.end(body);
};

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  try {
    if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/index.html')) {
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end(fs.readFileSync(path.join(__dirname, 'public', 'index.html')));
    }

    // --- The mock, exposed over HTTP so it can be driven with curl ---
    if (req.method === 'POST' && u.pathname === '/mock/v1/intention/') {
      const body = await readBody(req);
      if (!tokenOK(req, body)) return json(res, 401, { error: 'Invalid or missing access key.' });
      const r = mockIntention(body);
      return json(res, r.status, r.body);
    }
    if (req.method === 'POST' && u.pathname === '/mock/api/acceptance/payments/pay') {
      const body = await readBody(req);
      if (!tokenOK(req, body)) return json(res, 401, { error: 'Invalid or missing access key.' });
      // Flow is inferred: authentication data present ⇒ external. Override with ?flow=native.
      const flow = u.searchParams.get('flow') ||
        ((body.source && body.source.three_ds_data) ? 'external' : 'native');
      const r = mockPay(body, flow);
      return json(res, r.status, r.body);
    }

    // ===================================================================
    // REAL STEP 1 — Acme Pay 3DS Standalone. Three calls the browser drives:
    //   1) /api/acme/setup     → setup_id + collect_url (browser does the
    //                            device-data collection iframe, then step 2)
    //   2) /api/acme/authenticate → 3DS-only payment; inline values OR challenge
    //   3) /api/acme/poll      → after the challenge, read the final values
    // ===================================================================
    // Tells the UI whether server-side keys are configured (so it can hide the key fields
    // and run without anyone pasting). Never returns the secret itself.
    if (req.method === 'GET' && u.pathname === '/api/acme/config') {
      return json(res, 200, {
        configured: !!ACME_PRIV || AUTH_MODE === 'providers',
        requiresToken: !!SHARE_TOKEN,   // UI collects the shareable access key (token mode)
        authMode: AUTH_MODE,            // 'token' | 'providers' → UI shows key vs login
        prod: PROD_MODE,                // production rails → Visa/MC only, real cards
        host: ACME_HOST,
        account_masked: ACME_ACCT ? ACME_ACCT.slice(0, 8) + '…' : '',
      });
    }

    // Per-provider login (providers mode). Username + password → short-lived signed session.
    // The password is never logged; the response carries no Acme Pay credential.
    if (req.method === 'POST' && u.pathname === '/api/login') {
      const b = await readBody(req);
      if (AUTH_MODE !== 'providers') return json(res, 400, { error: 'Login is not enabled on this instance.' });
      if (!SESSION_SECRET) return json(res, 500, { error: 'Server missing SESSION_SECRET.' });
      const rec = PROVIDERS[String(b.username || '').trim()];
      if (!rec || !verifyPassword(String(b.password || ''), rec)) {
        return json(res, 401, { error: 'Invalid username or password.' });
      }
      return json(res, 200, {
        session: signSession(String(b.username).trim()),
        provider: String(b.username).trim(),
        label: rec.label || b.username,
        schemes: (rec.schemes || ['visa', 'mastercard']).map((s) => s.toLowerCase()),
        ttl_min: SESSION_TTL_MIN,
      });
    }

    if (req.method === 'POST' && u.pathname === '/api/acme/setup') {
      const b = await readBody(req);
      const auth = authContext(req, b);
      if (!auth.ok) return json(res, 401, { error: AUTH_MODE === 'providers' ? 'Please log in first.' : 'Invalid or missing access key.' });
      const rY = resolveAcme(b, auth.provider);
      const { creds, account_id, host } = rY;
      if (!creds.private_key) {
        return json(res, 400, { error: 'No Acme Pay credentials — set ACME_PUB/ACME_PRIV in the server env, or enter keys in the UI.' });
      }
      // Production Visa/MC-only guard (no-op in sandbox). Card number never logged.
      const guard = prodSchemeGuard(String((b.card || {}).number || '').replace(/\s/g, ''), rY.schemes);
      if (guard) return json(res, 200, { blocked: true, message: guard });
      // The 3ds_connection metadata MUST match on setup and payment, or the payment
      // routes to a different (or no) 3DS connection and returns null values. Fall back to
      // the provider's / server default connection.
      const conn = b.connection || rY.connection || ACME_CONN;
      const setupMeta = conn ? [{ key: '3ds_connection', value: conn }] : undefined;
      // NOTE: `type` is omitted deliberately — the API rejects `type: "STANDARD"` with
      // INVALID_PARAMETERS %!(EXTRA string=type); STANDARD is the default anyway.
      const r = await acme(host, creds, 'POST', '/v1/three-d-secure/setups', {
        account_id,
        card: acmeCard(b.card),
        ...(setupMeta ? { metadata: setupMeta } : {}),
      });
      return json(res, 200, r);
    }

    if (req.method === 'POST' && u.pathname === '/api/acme/authenticate') {
      const b = await readBody(req);
      const auth = authContext(req, b);
      if (!auth.ok) return json(res, 401, { error: AUTH_MODE === 'providers' ? 'Please log in first.' : 'Invalid or missing access key.' });
      const rY = resolveAcme(b, auth.provider);
      const { creds, account_id, host } = rY;
      if (!creds.private_key) {
        return json(res, 400, { error: 'No Acme Pay credentials configured.' });
      }
      const aGuard = prodSchemeGuard(String((b.card || {}).number || '').replace(/\s/g, ''), rY.schemes);
      if (aGuard) return json(res, 200, { ok: false, blocked: true, classification: { state: 'blocked' }, error: aGuard });
      // customer_payer.id must reference an existing Acme Pay customer, not a random UUID —
      // create one on the fly unless the caller supplied a customer_id.
      let customerId = b.customer_id;
      if (!customerId) {
        const c = await acme(host, creds, 'POST', '/v1/customers', {
          account_id,
          merchant_customer_id: 'poc-' + crypto.randomUUID(),
          first_name: 'Test', last_name: 'Customer',
          country: b.country || 'AR', email: 'test@example.com',
        });
        customerId = c.body && c.body.id;
        if (!customerId) return json(res, 200, { customer_create: c,
          classification: { state: 'error' },
          error: 'Could not create a customer — see customer_create.' });
      }
      // Same 3ds_connection as setup so authenticate routes identically.
      const conn = b.connection || rY.connection || ACME_CONN;
      // Every financial parameter is FIXED server-side. The access key can only ever trigger
      // a no-charge, authenticate-only 3DS run — amount, currency, workflow and the 3DS_ONLY
      // flag are not overridable by the caller, so the token cannot be used to move money.
      const pay = await acme(host, creds, 'POST', '/v1/payments', {
        account_id,
        description: '3DS PoC — authenticate only',
        country: 'AR',
        merchant_order_id: 'poc-' + crypto.randomUUID(),
        workflow: 'DIRECT',
        callback_url: 'https://example.com/return',
        amount: { currency: 'USD', value: '1.00' },
        // 3DS_ONLY:1 makes it authenticate-only (no charge) — hardcoded, not from the caller.
        metadata: [
          { key: '3DS_ONLY', value: '1' },
          ...(conn ? [{ key: '3ds_connection', value: conn }] : []),
        ],
        customer_payer: { id: customerId },
        payment_method: {
          type: 'CARD',
          detail: {
            card: {
              three_d_secure: { three_d_secure_setup_id: b.setup_id },
              card_data: acmeCard(b.card),
            },
          },
        },
      });
      const cls = classifyAcmePayment(pay);
      const extracted = cls.state === 'verified' ? extractThreeDS(pay.body, b.provider_id) : null;
      return json(res, 200, { payment: pay, classification: cls, extracted });
    }

    if (req.method === 'POST' && u.pathname === '/api/acme/poll') {
      const b = await readBody(req);
      const auth = authContext(req, b);
      if (!auth.ok) return json(res, 401, { error: 'Please log in first.' });
      const { creds, host } = resolveAcme(b, auth.provider);
      if (!creds.private_key || !b.payment_id) {
        return json(res, 400, { error: 'credentials + payment_id required.' });
      }
      const pay = await acme(host, creds, 'GET', '/v1/payments/' + encodeURIComponent(b.payment_id));
      // GET /v1/payments/{id} wraps the object in a `payment` envelope — unwrap it so
      // classify/extract see the same shape as the POST /v1/payments response.
      if (pay.body && pay.body.payment && !pay.body.status) pay.body = pay.body.payment;
      const cls = classifyAcmePayment(pay);
      const extracted = cls.state === 'verified' ? extractThreeDS(pay.body, b.provider_id) : null;
      return json(res, 200, { payment: pay, classification: cls, extracted });
    }

    // --- ACS OTP relay: start (POST CReq server-side, parse the challenge form) ---
    if (req.method === 'POST' && u.pathname === '/api/acs/start') {
      // SANDBOX ONLY. In production the cardholder completes the challenge on their issuer's
      // real ACS via a browser redirect — the server must never relay a real 3DS challenge
      // (it would intercept the bank's authentication and hold the live PAN in memory).
      if (PROD_MODE) return json(res, 400, { error: 'ACS relay is disabled in production — complete the challenge via the redirect.' });
      const b = await readBody(req);
      if (!tokenOK(req, b)) return json(res, 401, { error: 'Invalid or missing access key.' });
      if (!b.acs_url || !b.creq) return json(res, 400, { error: 'acs_url + creq required.' });
      const r = await httpForm(b.acs_url, {}, 'creq=' + encodeURIComponent(b.creq));
      if (r.status !== 200) return json(res, 200, { ok: false, status: r.status });
      const { action, fields } = parseAcsForm(r.body, b.acs_url);
      if (!action) return json(res, 200, { ok: false, error: 'No form found in the ACS page.' });
      const id = 'ch_' + crypto.randomUUID();
      acsSessions.set(id, { action, fields, cookie: r.cookies.map((c) => c.split(';')[0]).join('; ') });
      setTimeout(() => acsSessions.delete(id), 10 * 60 * 1000);
      return json(res, 200, { ok: true, challenge_id: id });
    }

    // --- ACS OTP relay: submit the user's OTP ---
    if (req.method === 'POST' && u.pathname === '/api/acs/otp') {
      if (PROD_MODE) return json(res, 400, { error: 'ACS relay is disabled in production.' });
      const b = await readBody(req);
      if (!tokenOK(req, b)) return json(res, 401, { error: 'Invalid or missing access key.' });
      const s = acsSessions.get(b.challenge_id);
      if (!s) return json(res, 400, { error: 'Unknown or expired challenge_id — run the authentication again.' });
      const params = new URLSearchParams({ ...s.fields, otp: String(b.otp || '') });
      const r = await httpForm(s.action, s.cookie ? { Cookie: s.cookie } : {}, params.toString());
      acsSessions.delete(b.challenge_id);
      return json(res, 200, { ok: r.status === 200 || r.status === 302, status: r.status });
    }

    // --- One-shot: setup + customer + authenticate → clean 3DS values ---
    // Built for the Postman collection: Paymob POSTs a card + access key and gets back real
    // ECI / CAVV / DS transaction id, without ever seeing a Acme Pay key. Frictionless only —
    // a challenge card needs the interactive UI flow.
    if (req.method === 'POST' && u.pathname === '/api/generate') {
      const b = await readBody(req);
      const auth = authContext(req, b);
      if (!auth.ok) return json(res, 401, { error: AUTH_MODE === 'providers' ? 'Please log in first.' : 'Invalid or missing access key.' });
      const rY = resolveAcme(b, auth.provider);
      const { creds, account_id, host } = rY;
      if (!creds.private_key) return json(res, 400, { error: 'No Acme Pay credentials configured on the server.' });
      if (!b.card || !b.card.number) return json(res, 400, { error: 'Provide a card: { number, expiry_month, expiry_year, cvn, name }.' });
      const pan = String(b.card.number).replace(/\s/g, '');
      // Production Visa/MC-only guard (no-op in sandbox). PAN never logged.
      const gGuard = prodSchemeGuard(pan, rY.schemes);
      if (gGuard) return json(res, 200, { ok: false, blocked: true, error: gGuard });
      // Mada parity with the UI (sandbox only): detect Mada BINs (or an explicit scheme:"MADA"
      // flag) so the API path labels real co-brand authentications MADA and falls back to
      // clearly-marked simulated values for PANs that cannot authenticate on the sandbox rails.
      const madaCard = !PROD_MODE && (String(b.scheme || '').toUpperCase() === 'MADA' || isMadaBin(pan));

      // Path 1 (international) uses the default connection unless the caller names one.
      const conn = ('connection' in b) ? b.connection : (rY.connection || ACME_CONN);

      const setup = await acme(host, creds, 'POST', '/v1/three-d-secure/setups', {
        account_id, card: acmeCard(b.card),
        ...(conn ? { metadata: [{ key: '3ds_connection', value: conn }] } : {}),
      });
      const sid = setup.body && setup.body.three_d_secure_setup_id;
      if (!sid) {
        if (madaCard) return json(res, 200, { ok: true, state: 'simulated', simulated: true,
          provider: 'SIMULATED_MADA_DS', three_d_secure_values: simulatedMadaValues(), note: SIMULATED_MADA_NOTE });
        return json(res, 200, { ok: false, step: 'setup', detail: setup.body });
      }

      // country + currency steer Acme Pay's 3DS routing: SA/SAR → Checkout (Mada),
      // everything else → Netcetera (international). Default to AR/USD (Netcetera).
      const country = b.country || 'AR';
      const currency = b.currency || 'USD';
      const cust = await acme(host, creds, 'POST', '/v1/customers', {
        account_id, merchant_customer_id: 'poc-' + crypto.randomUUID(),
        first_name: 'Test', last_name: 'Customer', country, email: 'test@example.com',
      });
      const cid = cust.body && cust.body.id;
      if (!cid) return json(res, 200, { ok: false, step: 'customer', detail: cust.body });

      const pay = await acme(host, creds, 'POST', '/v1/payments', {
        account_id, description: '3DS PoC — authenticate only', country,
        merchant_order_id: 'poc-' + crypto.randomUUID(), workflow: 'DIRECT',
        callback_url: 'https://example.com/return', amount: { currency, value: '1.00' },
        metadata: [
          { key: '3DS_ONLY', value: '1' },
          ...(conn ? [{ key: '3ds_connection', value: conn }] : []),
        ],
        customer_payer: { id: cid },
        payment_method: { type: 'CARD', detail: { card: {
          three_d_secure: { three_d_secure_setup_id: sid },
          card_data: acmeCard(b.card),
        } } },
      });
      const cls = classifyAcmePayment(pay);
      const extracted = cls.state === 'verified'
        ? extractThreeDS(pay.body, setup.body.provider_id) : null;
      // Mada: label real co-brand authentications; simulate when the PAN can't authenticate.
      if (madaCard && cls.state === 'verified' && extracted) {
        extracted.mpi.auth_scheme = 'MADA';
      }
      if (madaCard && cls.state !== 'verified' && cls.state !== 'challenge') {
        return json(res, 200, { ok: true, state: 'simulated', simulated: true,
          provider: 'SIMULATED_MADA_DS', three_d_secure_values: simulatedMadaValues(), note: SIMULATED_MADA_NOTE });
      }
      return json(res, 200, {
        ok: cls.state === 'verified',
        state: cls.state,
        payment_status: pay.body && pay.body.status,
        sub_status: pay.body && pay.body.sub_status,
        provider: setup.body.provider_id,
        // The five values Paymob feeds into its authorization, ready to use:
        three_d_secure_values: extracted ? extracted.mpi : null,
        note: cls.state === 'challenge'
          ? 'This card requires a challenge — use the browser UI to complete it (OTP 1234).'
          : (madaCard && cls.state === 'verified'
              ? 'Real EMV authentication via the co-brand rail, labeled MADA. Production CAVV validation is acquirer↔Mada DS.'
              : (cls.state !== 'verified' ? 'No values — see raw.' : undefined)),
        raw: extracted ? extracted.raw : (pay.body || null),
      });
    }

    // --- Run: intention → pay, against MOCK or LIVE ---
    if (req.method === 'POST' && u.pathname === '/api/run') {
      const b = await readBody(req);
      if (!tokenOK(req, b)) return json(res, 401, { error: 'Invalid or missing access key.' });
      const flow = b.flow === 'native' ? 'native' : 'external';
      const intentionBody = buildIntention(b);
      const sourceBody = buildSource(b);

      let intention, pay;
      if (b.mode === 'live') {
        if (!b.secret_key) return json(res, 400, { error: 'Live mode needs your own Paymob secret key.' });
        intention = await live(b.host || DEFAULT_HOST, 'POST', '/v1/intention/',
          { Authorization: `Token ${b.secret_key}` }, intentionBody);
        const key = intention.body && intention.body.payment_keys &&
          intention.body.payment_keys[0] && intention.body.payment_keys[0].key;
        if (!key) {
          return json(res, 200, {
            flow, mode: b.mode,
            request: { intention: intentionBody, source: sourceBody },
            intention, pay: null,
            verdict: { state: 'other', label: 'No payment_keys returned',
              detail: 'Intention failed — check the integration id, currency and key.' },
          });
        }
        // payment_keys[0].key, NOT client_secret — client_secret 401s here.
        pay = await live(b.host || DEFAULT_HOST, 'POST', '/api/acceptance/payments/pay', {},
          { source: sourceBody, payment_token: key });
      } else {
        intention = mockIntention(intentionBody);
        pay = mockPay({ source: sourceBody, payment_token: intention.body.payment_keys[0].key }, flow);
      }

      return json(res, 200, {
        flow, mode: b.mode,
        request: { intention: intentionBody, source: sourceBody },
        intention, pay,
        verdict: verdict(pay, !!(b.flow === 'external' && b.mpi), flow),
      });
    }

    json(res, 404, { error: 'not found' });
  } catch (e) {
    json(res, 500, { error: String((e && e.message) || e) });
  }
});

server.listen(PORT, () => {
  console.log(`\n  Paymob 3DS simulator — native vs external, international vs Mada`);
  console.log(`  → http://localhost:${PORT}`);
  console.log(`  mock:  POST /mock/v1/intention/`);
  console.log(`         POST /mock/api/acceptance/payments/pay[?flow=native|external]`);
  console.log(`  live:  ${DEFAULT_HOST} — your own credentials, entered in the UI, never stored`);
  console.log(`  step1: ${ACME_HOST} — real 3DS via Acme Pay staging (needs a 3DS-enabled account)\n`);
});
