#!/usr/bin/env node
/**
 * Moyasar External 3DS (External MPI) Simulator — zero-dependency Node server.
 *
 * Proxies the Moyasar sandbox API so the browser UI never holds the secret key
 * and there are no CORS issues. The external MPI payload (card_auth_data) is
 * passed straight through from the UI to Moyasar verbatim.
 *
 *   node moyasar-simulator/server.js
 *   open http://localhost:4000
 *
 * Keys default to the shared sandbox test keys; override with env vars:
 *   MOYASAR_PK=pk_test_... MOYASAR_SK=sk_test_... PORT=4000 node server.js
 */
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const PK = process.env.MOYASAR_PK || 'pk_test_DEMO_KEY_HIDDEN';
const SK = process.env.MOYASAR_SK || 'sk_test_DEMO_KEY_HIDDEN';
const HOST = process.env.MOYASAR_HOST || 'api.moyasar.com';
const PORT = process.env.PORT || 4000;

// --- Moyasar API call (Basic auth: key as username, empty password) ---
function moyasar(method, pathname, key, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const opts = {
      host: HOST,
      path: '/v1' + pathname,
      method,
      headers: {
        Authorization: 'Basic ' + Buffer.from(key + ':').toString('base64'),
        'Content-Type': 'application/json',
        ...(data ? { 'Content-Length': Buffer.byteLength(data) } : {}),
      },
    };
    const r = https.request(opts, (res) => {
      let buf = '';
      res.on('data', (d) => (buf += d));
      res.on('end', () => {
        let parsed;
        try { parsed = JSON.parse(buf); } catch { parsed = { raw: buf }; }
        resolve({ status: res.statusCode, body: parsed });
      });
    });
    r.on('error', reject);
    if (data) r.write(data);
    r.end();
  });
}

const readBody = (req) =>
  new Promise((resolve) => {
    let b = '';
    req.on('data', (d) => (b += d));
    req.on('end', () => { try { resolve(b ? JSON.parse(b) : {}); } catch { resolve({}); } });
  });

const json = (res, code, obj) => {
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(obj));
};

// Build the `source` object for a card payment from the UI inputs.
function buildCardSource(b) {
  const s = {
    type: 'creditcard',
    name: b.card.name,
    number: String(b.card.number).replace(/\s/g, ''),
    month: b.card.month,
    year: b.card.year,
    cvc: b.card.cvc,
  };
  if (b.save_card) s.save_card = true;            // NOTE: must live INSIDE source
  if (b.card_auth_data) s.card_auth_data = b.card_auth_data; // external MPI, passed verbatim
  return s;
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  try {
    // --- static UI ---
    if (req.method === 'GET' && (u.pathname === '/' || u.pathname === '/index.html')) {
      const html = fs.readFileSync(path.join(__dirname, 'public', 'index.html'));
      res.writeHead(200, { 'Content-Type': 'text/html' });
      return res.end(html);
    }
    if (req.method === 'GET' && u.pathname === '/api/keys') {
      return json(res, 200, { pk: 'pk_test_••••••• (hidden)', sk: 'sk_test_••••••• (hidden)', host: HOST });
    }

    // --- CIT: external-MPI payment (+ optional save_card) → auto-fetch source ---
    if (req.method === 'POST' && u.pathname === '/api/cit') {
      const b = await readBody(req);
      const pay = await moyasar('POST', '/payments', PK, {
        amount: b.amount,
        currency: b.currency,
        callback_url: b.callback_url || 'https://example.com/return',
        source: buildCardSource(b),
      });
      let source = null;
      if (pay.body && pay.body.id) source = await moyasar('GET', `/payments/${pay.body.id}/source`, SK);
      return json(res, 200, { request_source: buildCardSource(b), payment: pay, source });
    }

    // --- MIT: charge a saved token → auto-fetch source ---
    if (req.method === 'POST' && u.pathname === '/api/mit') {
      const b = await readBody(req);
      const source = { type: 'token', token: b.token };
      if (b.threeds === false) source['3ds'] = false;        // INSIDE source disables 3DS
      if (b.card_auth_data) source.card_auth_data = b.card_auth_data;
      const pay = await moyasar('POST', '/payments', PK, {
        amount: b.amount,
        currency: b.currency,
        callback_url: b.callback_url || 'https://example.com/return',
        source,
      });
      let src = null;
      if (pay.body && pay.body.id) src = await moyasar('GET', `/payments/${pay.body.id}/source`, SK);
      return json(res, 200, { request_source: source, payment: pay, source: src });
    }

    // --- Standalone card_auth (Moyasar's own 3DS) ---
    if (req.method === 'POST' && u.pathname === '/api/card-auth') {
      const b = await readBody(req);
      const pay = await moyasar('POST', '/card_auths', PK, {
        amount: b.amount,
        currency: b.currency,
        callback_url: b.callback_url || 'https://example.com/return',
        source: {
          type: 'creditcard', name: b.card.name,
          number: String(b.card.number).replace(/\s/g, ''),
          month: b.card.month, year: b.card.year, cvc: b.card.cvc,
        },
      });
      return json(res, 200, { card_auth: pay });
    }

    // --- Fetch source for any payment id ---
    if (req.method === 'GET' && u.pathname.startsWith('/api/source/')) {
      const id = u.pathname.split('/').pop();
      return json(res, 200, { source: await moyasar('GET', `/payments/${id}/source`, SK) });
    }

    json(res, 404, { error: 'not found' });
  } catch (e) {
    json(res, 500, { error: String(e && e.message || e) });
  }
});

server.listen(PORT, () => {
  console.log(`\n  Moyasar External 3DS simulator`);
  console.log(`  → http://localhost:${PORT}`);
  console.log(`  host=${HOST}  pk=(hidden)  sk=(hidden)\n`);
});
